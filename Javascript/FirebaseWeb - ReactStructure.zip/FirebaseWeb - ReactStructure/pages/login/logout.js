function logout() {
  //todo
}

export default logout();
